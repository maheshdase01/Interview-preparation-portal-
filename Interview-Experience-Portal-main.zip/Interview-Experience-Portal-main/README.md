# Interview-Experience-Portal
Interview Experience Portal using MERN stack to collect interview experiences of students during their internships or placemens. 
