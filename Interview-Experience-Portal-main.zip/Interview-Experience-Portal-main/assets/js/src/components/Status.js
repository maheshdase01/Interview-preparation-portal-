export default {
  props: ["mode", "active", "files", "cursor"],

  data() {
    return {
      font: 13,
      theme: "material-ocean",
    };
  },
  

};
