/**
 * This file will control the switching of schedule layouts
 */
